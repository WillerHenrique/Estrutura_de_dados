import java.util.Random;

public class Questao1 {
    public static void main(String[] args) {
        int qtd = 10;
        int[] vet = new int[10];
        Random random = new Random();


        for (int i = 0; i < qtd; i++) {
            vet[i] = random.nextInt(100) + 1;
        }

        System.out.print("Vetor: ");
        for (int i = 0; i < qtd; i++) {
            System.out.print(vet[i] + " ");
        }
        System.out.println();

        int elementoBuscado = 42;


        int posicaoEncontrada = -1;
        for (int i = 0; i < qtd; i++) {
            if (vet[i] == elementoBuscado) {
                posicaoEncontrada = i;
                break;
            }
        }
        if (posicaoEncontrada != -1) {
            System.out.println("Elemento " + elementoBuscado + " encontrado na posição " + posicaoEncontrada);
        } else {
            System.out.println("Elemento " + elementoBuscado + " não foi localizado no vetor.");
        }
    }
}
